import React from 'react'

function HomePage() {
  return (
    <div className='home-page'>
        
    </div>
  )
}

export default HomePage